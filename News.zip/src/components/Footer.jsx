export default function Footer() {
    return(
        <div className="footer">
            Я не знаю зачем это тут . _ .
        </div>
    )
}